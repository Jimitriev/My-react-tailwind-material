import { BrowserRouter, Routes, Route } from 'react-router-dom'

import Login from './Login'
import SignUp from './SignUp'
import Navbar from '../components/navbar/navbar'
import Home from '../components/home'
const Layout = () => {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route exact path='/' element={<Login/>}/>
        <Route exact path='/login' element={<Login/>}/>
        <Route exact path='/register' element={<SignUp/>}/>
        <Route exact path='/home' element={<Home/>}/>
      </Routes>
    </BrowserRouter>
  )
}

export default Layout