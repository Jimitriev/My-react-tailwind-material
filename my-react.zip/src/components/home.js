import ContentContainer from "./homecontents/container/container";
import MainSlider from "./homecontents/mainslider";
function Home(props) {

  return (
      <div>
        <MainSlider />
        <ContentContainer />
        {/* <ProductTabs />
        <Brandslogo />
        <ProductCard slides={allProducts} /> */}
        {/* <ClientCarousel /> */}
      </div> 
  );

}

export default Home;