import React from 'react'
import subbanner1 from '../../images/subbanner1.jpg'
import subbanner2 from '../../images/subbanner2.jpg'
import subbanner3 from '../../images/subbanner3.jpg'
// import { Container } from 'react-dom'
import { Link } from 'react-router-dom'
function MainSlider() {
  return (
    <section className='watchsTypes'>
      <div className='container p-5'>
        <div className='d-flex justify-around'>
          <Link to='/home'>
            <img href='/home' src={subbanner1} alt='subbanner1'/>
          </Link>
          <Link to='/home'>
            <img href='/home' src={subbanner2} alt='subbanner2'/>
          </Link>
          <Link to='/home'>
            <img href='/home' src={subbanner3} alt='subbanner3'/>
          </Link>
        </div>
      </div>
    </section>
  )
}

export default MainSlider

