import { data } from 'autoprefixer'
import React from 'react'
import { Link } from 'react-router-dom'
import product1 from '../../../images/product1.jpg'
import product2 from '../../../images/product2.jpg'
import product3 from '../../../images/product3.jpg'
import product7 from '../../../images/product7.jpg'
import product8 from '../../../images/product8.jpg'
// import ProductElement from './producttabs/productcard/productelement/productelement'

function ContentContainer() {
    const image =[
      {name: product1},
      {name: product2},
      {name: product3},
      {name: product7},
      {name: product8}
    ]
    
  return (
    <div>
      <Link to='/home'>
        {data.map((props) => (
           <img src={image.name} alt='product1'/>
        ))}
      </Link>
      {/* <Link to='/home'>
        <img src={image[1]} alt='product2'/>
      </Link>
      <Link to='/home'>
        <img src={image[2]} alt='product3'/>
      </Link>
      <Link to='/home'>
        <img src={image[3]} alt='product7'/>
      </Link>
      <Link to='/home'>
        <img src={image[4]} alt='product8'/>
      </Link> */}
      {/* <ProductElement /> */}
    </div>
  )
}

export default ContentContainer
