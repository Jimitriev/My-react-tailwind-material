import { Carousel } from 'bootstrap'
import React from 'react'
import ProductElement from './productelement/productelement'

function ProductCard(props) {
  return (
    <div className='productSlider n=mb-5 mt-5'>
        <Container>
            <h5 className=' text-start mb-4 ms-4'>Featured Product</h5>
            <Carousel controls='false' responsive={productresponsive}>
                {slidess.map((slide) => (
                    <ProductElement slidepro={slide} clickWish={handleToWish} />
                ))}
            </Carousel>
        </Container>
      
    </div>
  );
}

export default ProductCard
