import React from 'react'

function ProductCard() {
  return (
    <div>
      asddf
    </div>
  )
}

export default ProductCard
